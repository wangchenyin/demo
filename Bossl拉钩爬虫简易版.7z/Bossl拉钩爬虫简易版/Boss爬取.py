from lxml import etree
import asyncio
from pyppeteer import launch
import time

async def main():
    browser = await launch(headless=False,logLevel='INFO',autoClose=False)#是打开浏览器，默认True
    page = await browser.newPage()
    await page.evaluateOnNewDocument('() =>{ Object.defineProperties(navigator,''{ webdriver:{ get: () => false } }) }')
    await page.setUserAgent(
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36")
    await page.setJavaScriptEnabled(enabled=True)
    # await page.setViewport({'width': width, 'height': height})
    area_liast = ['渝北区','渝中区','江北区','九龙坡区','南岸区','沙坪坝区']
    for area1 in area_liast:
        for num in range(1,11):
            url = "https://www.zhipin.com/c101040100/b_" + area1 + "/?query=%E6%95%B0%E6%8D%AE%E5%88%86%E6%9E%90&page="+str(num)+"&ka=page-"+str(num)
            await page.goto(url)
            await asyncio.sleep(10)
            html = await page.content()
            tree = etree.HTML(html)
            jobs_list = tree.xpath("//*[@id='main']/div/div[2]/ul/li")
            for once in jobs_list:
                job_name = once.xpath("./div/div[1]/div[1]/div/div[1]/span[1]/a/text()")[0]
                com_name = once.xpath("./div/div[1]/div[2]/div/h3/a/text()")[0]
                salary = once.xpath("./div/div[1]/div[1]/div/div[2]/span/text()")[0]
                area = once.xpath("./div/div[1]/div[1]/div/div[1]/span[2]/span/text()")[0]
                exp = once.xpath("./div/div[1]/div[1]/div/div[2]/p/text()[1]")[0]
                edu = once.xpath("./div/div[1]/div[1]/div/div[2]/p/text()[2]")[0]
                com_type = once.xpath("./div/div[1]/div[2]/div/p/a/text()")[0]
                com_nature = once.xpath("./div/div[1]/div[2]/div/p/text()[1]")[0]
                com_scope = once.xpath("./div/div[1]/div[2]/div/p/text()[2]")
                if com_scope == []:
                    com_scope = com_nature
                else:
                    com_scope = com_scope[0]
                # print(com_weal)
                with open("Boss_python.txt", 'a',encoding='utf-8') as file:
                    file.write("%s,%s,%s,%s,%s,%s,%s,%s,%s\n" % (
                        job_name,com_name,salary,area,exp,edu,com_type,com_nature,com_scope))
            click1_text = tree.xpath("//*[@ka='page-next']/@class")
            if click1_text != ['next']:
                print("%s地区岗位数据下载成功！"%(area1))
                continue
            time.sleep(1)

asyncio.get_event_loop().run_until_complete(main())

#
# browser = await launch(
#     headless=False,             # 运行时显示浏览器窗口
#     ignoreHTTPSErrors=False,    # 是否要忽略 HTTPS 的错误，默认是 False。
#     autoClose=True,             # 当一些命令执行完之后，是否自动关闭浏览器，默认是 True。
#     devtools=False,             # 是否为每一个页面自动开启调试工具，默认是 False
#     userDataDir=userDataDir,              # 即用户数据文件夹，即可以保留一些个性化配置和操作记录。
#     args=[f'--window-size={width},{height}', '--disable-infobars'],    # 浏览器窗口大小
#     logLevel='INFO',
# )
# 页面加载时自动执行JS内容
# await page.evaluateOnNewDocument('() =>{ Object.defineProperties(navigator,'
                                 # '{ webdriver:{ get: () => false } }) }')