import requests,json,time
import csv
import codecs
from lxml import etree
from selenium import webdriver
ff = webdriver.Firefox()
area1 = ['渝北区', '渝中区', '江北区', '九龙坡区', '南岸区', '沙坪坝区', '巴南区']
for area2 in area1:
    url = "https://www.lagou.com/jobs/list_%E6%95%B0%E6%8D%AE%E5%88%86%E6%9E%90/p-city_5?px=default&district=" + area2 +"#filterBox"
# https://www.lagou.com/jobs/list_%E6%95%B0%E6%8D%AE%E5%88%86%E6%9E%90/p-city_5?px=default
    ff.get(url)
    time.sleep(3)
    ff.refresh()
    time.sleep(3)
    job_list = ff.find_element_by_xpath("//div[@class='s_position_list ']")
    html = job_list.get_attribute('innerHTML')
    tree = etree.HTML(html)
    jobs = tree.xpath('.//ul/li')
    total_page = ff.find_element_by_xpath("//*[@id='order']")
    total_page = total_page.get_attribute('innerHTML')
    total_page = etree.HTML(total_page)
    total_page = int(total_page.xpath(".//li/div[4]/div[3]/span[2]/text()")[0])
    next_click = ff.find_element_by_xpath("//*[@id='order']/li/div[4]/div[2]")
    for i in range(1,total_page+1):

        for once in jobs:
            job_name = once.xpath("./div[1]/div[1]/div[1]/a/h3/text()")
            if job_name ==[]:
                job_name = ""
            else:
                job_name = job_name[0]
            print(job_name)
            area = once.xpath("./div[1]/div[1]/div[1]/a/span/em/text()")
            if area ==[]:
                area = ""
            else:
                area = area[0]
            salary = once.xpath("./div[1]/div[1]/div[2]/div/span/text()")
            if salary ==[]:
                salary = ""
                mean_salary = ""
            else:
                salary = salary[0]
                mean_salary = (int(salary.split("-")[0][0:-1]) + int(salary.split("-")[1][0:-1]))/2
            edu = once.xpath("./div[1]/div[1]/div[2]/div/text()")
            if edu ==[]:
                edu = ""
            else:
                edu = edu[2].strip().split("/")[1]
            exp = once.xpath("./div[1]/div[1]/div[2]/div/text()")
            if exp ==[]:
                exp =""
            else:
                exp = exp[2].strip().split("/")[0][2:-1]
            company = once.xpath("./div[1]/div[2]/div[1]/a/text()")
            if company == []:
                company = ""
            else:
                company = company[0]
            com_type = once.xpath("./div[1]/div[2]/div[2]/text()")
            if com_type == []:
                com_type=""
            else:
                com_type = com_type[0].split("/")[1].strip()
            com_scale = once.xpath("./div[1]/div[2]/div[2]/text()")
            if com_scale == []:
                com_scale =""
            else:
                com_scale = com_scale[0].split("/")[2].strip()
            com_position = once.xpath("./div[1]/div[2]/div[2]/text()")
            if com_position ==[]:
                com_position = ""
            else:
                com_position = com_position[0].split("/")[0].strip()
            # with open("job_info.txt",'a') as file:
                # file.write(codecs.BOM_UTF8)
                # writer = csv.writer(file)
                # writer.writerow([job_name,area,salary,mean_salary,area,edu,exp,company,com_type,com_scale,com_position])
            with open("job_info.txt", 'a') as file:
                file.write("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n"%(job_name,area,salary,mean_salary,area,edu,exp,company,com_type,com_scale,com_position))

        next_click.click()
        time.sleep(2)
# ff.quit()
# //*[@id="s_position_list"]
# //*[@id="s_position_list"]/ul/li[2]
# //*[@id="s_position_list"]/ul/li[2]/div[1]/div[1]/div[1]/a/h3
# //*[@id="order"]/li/div[4]/div[3]/span[2]

# //*[@id="s_position_list"]/ul/li[1]/div[1]/div[2]/div[2]
# //*[@id="s_position_list"]/ul/li[1]/div[1]/div[2]/div[1]/a
#//*[@id="s_position_list"]/ul/li[2]/div[1]/div[1]/div[1]/a/span/em
# //*[@id="s_position_list"]/ul/li[1]/div[1]/div[1]/div[2]/div/span
# //*[@id="s_position_list"]/ul/li[1]/div[1]/div[1]/div[2]/div/text()
# //*[@id="s_position_list"]
# (int(salary[0].split("-")[0][0:-1]) + int(salary[0].split("-")[1][0:-1]))/2
# https://www.lagou.com/jobs/list_%E6%95%B0%E6%8D%AE%E5%88%86%E6%9E%90/p-city_5?&cl=false&fromSearch=true&labelWords=&suginput=
# https://www.lagou.com/jobs/list_%E6%95%B0%E6%8D%AE%E5%88%86%E6%9E%90/p-city_5?&cl=false&fromSearch=true&labelWords=&suginput=